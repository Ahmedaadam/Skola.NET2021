﻿using System;

namespace Inlämning2
{
    class Program
    {
        static void Main(string[] args)
        {
            Setup.Init();
        }
    }
}
