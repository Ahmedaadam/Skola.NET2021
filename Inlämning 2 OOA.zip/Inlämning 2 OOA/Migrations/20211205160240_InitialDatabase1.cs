﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Inlämning2.Migrations
{
    public partial class InitialDatabase1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
